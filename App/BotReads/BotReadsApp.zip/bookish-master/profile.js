const books = [
    {
        title: "The Mystic Forest",
        publicationDate: "2020",
        publisher: "Fantasy House",
        cover: "images/mystic_forest.jpeg",
        description: "An epic journey into a magical forest.",
        purchaseLink: "#"
    },
    {
        title: "Shadows of Time",
        publicationDate: "2021",
        publisher: "Chronos Press",
        cover: "images/shadowsOfTime.jpg",
        description: "A thrilling tale of time travel.",
        purchaseLink: "#"
    },
    {
        title: "Can't Hurt Me",
        publicationDate: "2018",
        publisher: "Lioncrest Publishing",
        cover: "images/cant_hurt_me.jpeg",
        description: "A memoir by David Goggins that inspires readers to push beyond their limits and develop mental toughness.",
        purchaseLink: "#"
    },
    {
        title: "Rich Dad Poor Dad",
        publicationDate: "1997",
        publisher: "Warner Books Ed",
        cover: "images/richdad.jpeg",
        description: "A book that explores the mindset and financial principles of the wealthy, highlighting the differences between assets and liabilities.",
        purchaseLink: "#"
    }

];

const booksList = document.getElementById('books-list');

books.forEach(book => {
    const bookElement = document.createElement('div');
    bookElement.classList.add('book');

    bookElement.innerHTML = `
        <img src="${book.cover}" alt="${book.title} Cover">
        <div class="book-details">
            <h3>${book.title}</h3>
            <p>Published: ${book.publicationDate}</p>
            <p>Publisher: ${book.publisher}</p>
            <p>${book.description}</p>
            <a href="${book.purchaseLink}">Buy Now</a>
        </div>
    `;

    booksList.appendChild(bookElement);
});