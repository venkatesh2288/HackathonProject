import streamlit as st
from PyPDF2 import PdfReader
import io

# Title of the app
st.title("PDF Text Extraction")

# File uploader for PDF input
uploaded_file = st.file_uploader("Upload a PDF file", type=["pdf"])

if uploaded_file is not None:
    # Read the PDF file
    with st.spinner("Extracting text..."):
        pdf_reader = PdfReader(uploaded_file)
        extracted_text = ""
        for page in pdf_reader.pages:
            extracted_text += page.extract_text() + "\n"

        st.success("Text extracted successfully!")

    # Display the extracted text
    st.text_area("Extracted Text", extracted_text, height=400)

    # Provide a download button for the extracted text
    text_bytes = io.BytesIO()
    text_bytes.write(extracted_text.encode("utf-8"))
    text_bytes.seek(0)

    st.download_button(
        label="Download Extracted Text",
        data=text_bytes,
        file_name="extracted_text.txt",
        mime="text/plain",
    )


