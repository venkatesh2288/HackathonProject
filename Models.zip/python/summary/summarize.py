import streamlit as st
from transformers import pipeline

# Load summarization model
@st.cache_resource
def load_summarizer():
    return pipeline("summarization")

summarizer = load_summarizer()

# Streamlit app
st.title("Text Summarization App")

# Input text area
input_text = st.text_area("Enter the text to summarize:", height=200)

# Button to summarize
if st.button("Summarize"):
    if input_text.strip():
        with st.spinner("Summarizing..."):
            try:
                summary = summarizer(input_text, max_length=130, min_length=30, do_sample=False)[0]['summary_text']
                st.success("Summary:")
                st.write(summary)
            except Exception as e:
                st.error(f"An error occurred: {e}")
    else:
        st.warning("Please enter some text to summarize.")

# Download summarized text
if 'summary' in locals() and summary:
    st.download_button(
        label="Download Summary",
        data=summary,
        file_name="summary.txt",
        mime="text/plain",
    )