import streamlit as st
import pyttsx3


st.title("Text to Speech Converter")
st.write("Enter the text below, adjust settings, and click the button to hear it.")


text_input = st.text_area("Enter text here:")


engine = pyttsx3.init()

def convert_text_to_speech(text, rate, volume, voice_type):
    engine.setProperty('rate', rate)
    
    
    engine.setProperty('volume', volume)
    
    # Set the voice (male/female)
    voices = engine.getProperty('voices')
    if voice_type == "Male":
        engine.setProperty('voice', voices[0].id) 
    else:
        engine.setProperty('voice', voices[1].id) 
    
    # Convert text to speech
    if text.strip():
        engine.say(text) 
        engine.runAndWait() 
    else:
        st.write("Please enter some text to convert.")


rate = st.slider("Speech Rate", 100, 300, 150) 
volume = st.slider("Volume", 0.0, 1.0, 1.0) 
voice_type = st.selectbox("Select Voice", ["Male", "Female"]) 

if st.button("Convert to Speech"):
    if text_input.strip():
        convert_text_to_speech(text_input, rate, volume, voice_type)
    else:
        st.write("Please enter some text to convert.")


